# SFRUDDONAT — The Four Starters

## Cosa contiene
- `index.html`: pagina iniziale del gioco.
- `assets/sfruddonat-start-screen.png`: schermata pixel-art generata.
- Le quattro aree invisibili sulla schermata sono cliccabili: selezionano NicoPav, Alessio, Matteo o Gigi.
- PLAY apre una prima schermata introduttiva per il personaggio scelto.

## Provarlo sul computer
Apri `index.html` con un browser. Per pubblicarlo online, carica l'intera cartella su GitHub e attiva GitHub Pages:
1. Crea un repository GitHub, ad esempio `sfruddonat`.
2. Carica `index.html` e la cartella `assets` mantenendo la stessa struttura.
3. Vai in Settings → Pages.
4. In Build and deployment scegli Deploy from a branch, seleziona `main` e `/ (root)`, poi Save.
5. Dopo la pubblicazione GitHub mostrerà il link del gioco.

Questa è una prima base interattiva: i livelli veri e propri (movimento, ostacoli, obiettivi e boss) vanno aggiunti nel prossimo passaggio.
